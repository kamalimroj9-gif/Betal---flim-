// Synthesises every sound used by the film into public/*.wav (no downloads needed).
const fs = require('fs'); const path = require('path');
const SR = 22050, out = path.join(__dirname, '..', 'public'); fs.mkdirSync(out, {recursive: true});
const wav = (name, secs, fn) => {
  const n = Math.floor(SR * secs), b = Buffer.alloc(44 + n * 2);
  b.write('RIFF', 0); b.writeUInt32LE(36 + n * 2, 4); b.write('WAVEfmt ', 8); b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22);
  b.writeUInt32LE(SR, 24); b.writeUInt32LE(SR * 2, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34); b.write('data', 36); b.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) { const v = Math.max(-1, Math.min(1, fn(i / SR, i, secs))); b.writeInt16LE(Math.floor(v * 32000), 44 + i * 2); }
  fs.writeFileSync(path.join(out, name + '.wav'), b);
};
const S = Math.sin, TAU = Math.PI * 2, rnd = () => Math.random() * 2 - 1;
const notes = [220, 261.6, 246.9, 196, 220, 293.7, 261.6, 196];
wav('music', 53, (t) => {
  const trem = 0.75 + 0.25 * S(TAU * 0.2 * t);
  const drone = (S(TAU * 55 * t) * 0.3 + S(TAU * 82.4 * t) * 0.18 + S(TAU * 110.3 * t) * 0.1) * trem;
  const k = Math.floor(t / 3) % notes.length, lt = t % 3, f = notes[k];
  const pluck = S(TAU * f * t) * Math.exp(-lt * 1.6) * 0.25 + S(TAU * f * 2 * t) * Math.exp(-lt * 3) * 0.08;
  return (drone + pluck) * 0.8;
});
let y = 0; wav('rain', 4, (t, i, d) => { y += 0.35 * (rnd() - y); const e = Math.min(1, t * 20, (d - t) * 20); return y * 0.9 * e; });
y = 0; wav('thunder', 3, (t) => { y += 0.04 * (rnd() - y); return y * 6 * Math.exp(-t * 1.3) * Math.min(1, t * 15); });
wav('step', 0.18, (t) => (S(TAU * 90 * t) * 0.6 + rnd() * 0.12) * Math.exp(-t * 28));
wav('slash', 0.3, (t) => rnd() * Math.sin(Math.min(1, t / 0.3) * Math.PI) * 0.5 * Math.exp(-t * 6) + S(TAU * (2500 - t * 6000) * t) * 0.15 * Math.exp(-t * 10));
wav('thud', 0.5, (t) => (S(TAU * 60 * t) * 0.9 + rnd() * 0.15) * Math.exp(-t * 9));
wav('cry', 2.2, (t, i, d) => S(TAU * (380 + 90 * S(TAU * 5 * t)) * t) * 0.35 * (0.6 + 0.4 * S(TAU * 1.6 * t)) * Math.min(1, t * 6, (d - t) * 3));
wav('laugh', 1.9, (t, i, d) => { const g = Math.max(0, S(TAU * 4.2 * t)); const f = 160 + 60 * S(TAU * 2 * t); return (((t * f) % 1) * 2 - 1) * 0.3 * g * g * Math.min(1, (d - t) * 3); });
console.log('Audio written to public/');
