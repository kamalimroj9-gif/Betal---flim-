# বেতালপঞ্চবিংশতি – Remotion film (1920x1080, 24 fps, 52.5 s)
Based on Vidyasagar's text (public domain). All characters are original SVG.

## Run
    npm install
    npm run audio     # synthesises music + sound effects into public/
    npm start         # live preview in Remotion Studio
    npm run build     # renders out/betal.mp4

Needs Node 18+ and internet on first render (Noto Sans Bengali font via @remotion/google-fonts).

## Layout
constants.ts (timeline, subtitles, lip-sync) · Face.tsx (expressions) · Character.tsx (king, yogi, corpse; walk/sit/climb cycles)
Backgrounds.tsx (layered parallax scenery, weather, fire) · Camera.tsx · Transitions.tsx · Sound.tsx · Film.tsx (main composition)
