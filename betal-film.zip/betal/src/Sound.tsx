import React from 'react';
import {Audio, Sequence, staticFile, interpolate} from 'remotion';
import {FLASH, TOTAL, WALK_RANGES} from './constants';
const sfx = (name: string, f: number, vol = 0.6) => (
  <Sequence key={name + f} from={f} durationInFrames={72}><Audio src={staticFile(name + '.wav')} volume={vol} /></Sequence>
);
export const MusicTrack: React.FC = () => (
  <Audio src={staticFile('music.wav')} loop volume={(f) => 0.4 * interpolate(f, [0, 30, TOTAL - 40, TOTAL], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
);
export const SoundEffects: React.FC = () => (
  <>
    <Sequence from={400} durationInFrames={TOTAL - 400}><Audio src={staticFile('rain.wav')} loop volume={0.28} /></Sequence>
    {FLASH.map((f) => sfx('thunder', f + 6, 0.7))}
    {WALK_RANGES.flatMap(([a, b]) => Array.from({length: Math.floor((b - a) / 8)}, (_, i) => sfx('step', a + i * 8, 0.35)))}
    {sfx('slash', 1080, 0.7)}{sfx('thud', 1100, 0.8)}{sfx('cry', 1108, 0.5)}{sfx('laugh', 1205, 0.7)}
  </>
);
