import React from 'react';
import {random} from 'remotion';
import {W, H, GROUND, FLASH} from './constants';
const WORLD = 3600;
const tr = (pan: number, f: number) => `translate(${-pan * f} 0)`;

export const Sky: React.FC<{warm?: boolean}> = ({warm}) => (
  <g>
    <defs>
      <linearGradient id={`sky${warm ? 1 : 0}`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={warm ? '#1a0c1e' : '#050b1f'} />
        <stop offset="0.6" stopColor={warm ? '#4a1a1f' : '#14284d'} />
        <stop offset="1" stopColor={warm ? '#7a3320' : '#2a3f66'} />
      </linearGradient>
    </defs>
    <rect width={W} height={H} fill={`url(#sky${warm ? 1 : 0})`} />
  </g>
);
export const Stars: React.FC<{t: number}> = ({t}) => (
  <g>{Array.from({length: 90}, (_, i) => (
    <circle key={i} cx={random('sx' + i) * W} cy={random('sy' + i) * 520} r={0.8 + random('sr' + i) * 1.6}
      fill="#fff" opacity={0.35 + 0.35 * Math.sin(t / 10 + i)} />))}</g>
);
export const Moon: React.FC = () => (
  <g>
    <defs><radialGradient id="moonG"><stop offset="0" stopColor="#fff6c8" stopOpacity={0.55} /><stop offset="1" stopColor="#fff6c8" stopOpacity={0} /></radialGradient></defs>
    <circle cx={1500} cy={170} r={260} fill="url(#moonG)" />
    <circle cx={1500} cy={170} r={72} fill="#f3efd2" />
    <circle cx={1478} cy={150} r={14} fill="#d8d2ae" /><circle cx={1522} cy={192} r={10} fill="#d8d2ae" /><circle cx={1516} cy={140} r={7} fill="#d8d2ae" />
  </g>
);
export const Clouds: React.FC<{t: number; speed?: number; dark?: number}> = ({t, speed = 0.4, dark = 0.7}) => (
  <g>{Array.from({length: 7}, (_, i) => {
    const x = ((random('cx' + i) * (W + 700) + t * speed * (0.6 + random('cv' + i))) % (W + 700)) - 350;
    const y = 70 + random('cy' + i) * 300, k = 0.8 + random('ck' + i) * 1.2;
    return (<g key={i} transform={`translate(${x} ${y}) scale(${k})`} fill="#0a1328" opacity={dark}>
      <ellipse rx={150} ry={34} /><ellipse cx={-70} cy={-22} rx={80} ry={38} /><ellipse cx={50} cy={-30} rx={90} ry={42} /></g>);
  })}</g>
);
const hillPath = (base: number, amp: number, seed: number) => {
  let d = `M0 ${H}`;
  for (let x = 0; x <= WORLD; x += 40) {
    const y = base - amp * (Math.sin(x * 0.0035 + seed) + 0.5 * Math.sin(x * 0.009 + seed * 2) + 0.25 * Math.sin(x * 0.021 + seed * 3));
    d += ` L${x} ${y.toFixed(1)}`;
  }
  return d + ` L${WORLD} ${H} Z`;
};
export const Hills: React.FC<{base: number; amp: number; seed: number; color: string; f: number; pan: number}> = ({base, amp, seed, color, f, pan}) => (
  <path d={hillPath(base, amp, seed)} fill={color} transform={tr(pan, f)} />
);
export const Trees: React.FC<{n: number; base: number; size: number; color: string; color2: string; f: number; pan: number; t: number; seed: string; dead?: boolean}> =
  ({n, base, size, color, color2, f, pan, t, seed, dead}) => (
  <g transform={tr(pan, f)}>{Array.from({length: n}, (_, i) => {
    const x = (i + random(seed + 'x' + i) * 0.8) * (WORLD / n), k = size * (0.7 + random(seed + 's' + i) * 0.6);
    const sway = Math.sin(t / 30 + i * 1.3) * 1.8, lf = Math.sin(t / 15 + i) * 3;
    return (
      <g key={i} transform={`translate(${x} ${base}) rotate(${sway})`}>
        <path d={`M${-9 * k} 0 Q${-6 * k} ${-120 * k} ${-3 * k} ${-200 * k} L${3 * k} ${-200 * k} Q${7 * k} ${-120 * k} ${10 * k} 0Z`} fill={color} />
        {dead ? (
          <g stroke={color} strokeWidth={6 * k} strokeLinecap="round" fill="none">
            <path d={`M0 ${-150 * k} L${-70 * k} ${-230 * k} M${-40 * k} ${-190 * k} L${-60 * k} ${-260 * k} M0 ${-190 * k} L${60 * k} ${-270 * k} M${30 * k} ${-230 * k} L${80 * k} ${-240 * k}`} />
          </g>
        ) : (
          <g>
            <ellipse cx={0} cy={-235 * k} rx={(95 + lf) * k} ry={72 * k} fill={color} />
            <ellipse cx={-62 * k} cy={-190 * k} rx={(62 + lf) * k} ry={50 * k} fill={color} />
            <ellipse cx={64 * k} cy={-196 * k} rx={(66 - lf) * k} ry={52 * k} fill={color} />
            <ellipse cx={-22 * k} cy={-250 * k} rx={50 * k} ry={34 * k} fill={color2} opacity={0.5} />
          </g>
        )}
      </g>);
  })}</g>
);
export const Ground: React.FC<{pan: number}> = ({pan}) => (
  <g>
    <defs><linearGradient id="gr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#16261a" /><stop offset="1" stopColor="#060c08" /></linearGradient></defs>
    <rect y={GROUND} width={W} height={H - GROUND} fill="url(#gr)" />
    <g transform={tr(pan, 1)} fill="#22402a">{Array.from({length: 110}, (_, i) => {
      const x = random('gx' + i) * WORLD, y = GROUND + 6 + random('gy' + i) * 170, k = 0.6 + random('gk' + i);
      return <path key={i} d={`M${x} ${y} l${-5 * k} ${-18 * k} l${5 * k} ${10 * k} l${2 * k} ${-20 * k} l${3 * k} ${20 * k} l${6 * k} ${-14 * k} l${-4 * k} ${22 * k}Z`} />;
    })}</g>
  </g>
);
export const River: React.FC<{t: number}> = ({t}) => (
  <g>
    <defs><linearGradient id="rv" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#1d3a62" /><stop offset="1" stopColor="#0a1a33" /></linearGradient></defs>
    <path d={`M0 740 Q500 722 1000 742 T1920 730 L1920 ${GROUND} L0 ${GROUND}Z`} fill="url(#rv)" />
    <ellipse cx={1500} cy={800} rx={60} ry={70} fill="#fff6c8" opacity={0.12} />
    {Array.from({length: 26}, (_, i) => {
      const x = ((random('rx' + i) * W + t * (0.5 + random('rs' + i))) % W), y = 750 + random('ry' + i) * 110;
      return <path key={i} d={`M${x} ${y} q18 -5 36 0`} stroke="#9fc0e8" strokeWidth={2} fill="none" opacity={0.45} />;
    })}
  </g>
);
export const Bats: React.FC<{t: number}> = ({t}) => (
  <g>{Array.from({length: 6}, (_, i) => {
    const x = ((i * 380 + t * (3 + (i % 3))) % (W + 200)) - 100, y = 160 + i * 55 + Math.sin(t / 10 + i) * 30;
    const fl = Math.sin(t * 0.9 + i);
    const wing = `M0 0 Q18 ${-16 * fl - 4} 40 ${-6 * fl + 4} Q22 6 0 7Z`;
    return (<g key={i} transform={`translate(${x} ${y})`} fill="#05070c"><path d={wing} /><g transform="scale(-1 1)"><path d={wing} /></g><circle r={5} cy={3} /></g>);
  })}</g>
);
export const Gravestones: React.FC<{n: number; pan: number; f: number; seed: string}> = ({n, pan, f, seed}) => (
  <g transform={tr(pan, f)}>{Array.from({length: n}, (_, i) => {
    const x = random(seed + i) * WORLD * 0.7, y = GROUND + 2 + random(seed + 'y' + i) * 40, k = 0.8 + random(seed + 'k' + i) * 0.7;
    return (<g key={i} transform={`translate(${x} ${y}) scale(${k})`}>
      <path d="M-22 0 V-60 Q0 -90 22 -60 V0Z" fill="#2a3345" /><path d="M0 -62 V-30 M-9 -48 H9" stroke="#475269" strokeWidth={4} /></g>);
  })}</g>
);
export const Ghosts: React.FC<{t: number; pan: number}> = ({t, pan}) => (
  <g transform={tr(pan, 0.8)}>{Array.from({length: 8}, (_, i) => {
    const x = 200 + random('gh' + i) * 2600 + Math.sin(t / 40 + i) * 40, y = 380 + random('gy' + i) * 320 + Math.sin(t / 25 + i) * 25;
    const op = 0.28 + 0.14 * Math.sin(t / 7 + i * 2);
    return (<g key={i} transform={`translate(${x} ${y}) scale(${1 + random('gs' + i)})`} opacity={op}>
      <path d="M-26 0 A26 26 0 0 1 26 0 V52 Q16 40 8 56 Q0 40 -8 56 Q-16 40 -26 52Z" fill="#cfe4ff" />
      <path d={`M-24 20 Q-48 ${5 + Math.sin(t / 8 + i) * 8} -52 -12 M24 20 Q48 ${5 - Math.sin(t / 8 + i) * 8} 52 -12`} stroke="#cfe4ff" strokeWidth={9} fill="none" strokeLinecap="round" />
      <ellipse cx={-9} cy={-2} rx={4} ry={7} fill="#06121f" /><ellipse cx={9} cy={-2} rx={4} ry={7} fill="#06121f" /><ellipse cy={16} rx={5} ry={8} fill="#06121f" />
    </g>);
  })}</g>
);
export const Flames: React.FC<{x: number; y: number; size: number; t: number; id?: number}> = ({x, y, size, t, id = 0}) => (
  <g>
    {[['#b3200f', 1, 0.5], ['#e8561a', 0.82, 0.38], ['#ffb12e', 0.6, 0.26], ['#fff0a0', 0.34, 0.14]].map(([c, hk, wk], i) => {
      const h = size * (hk as number) * (0.85 + 0.15 * Math.sin(t * 0.7 + i * 2 + id));
      const w = size * (wk as number), sw = Math.sin(t * 0.45 + i + id) * size * 0.08;
      return <path key={i} d={`M${x - w} ${y} Q${x - w * 0.5} ${y - h * 0.5} ${x + sw} ${y - h} Q${x + w * 0.6} ${y - h * 0.45} ${x + w} ${y}Z`} fill={c as string} />;
    })}
    {Array.from({length: 6}, (_, i) => {
      const p = ((t * 3 + i * 37 + id * 11) % 150) / 150;
      return <circle key={i} cx={x + Math.sin(t / 5 + i) * 20 + (i - 3) * 6} cy={y - size * 0.6 - p * 150} r={2.5 * (1 - p)} fill="#ffcf5a" opacity={1 - p} />;
    })}
  </g>
);
export const Glow: React.FC<{x: number; y: number; r: number; t: number; id: string; color?: string}> = ({x, y, r, t, id, color = '#ff8a2a'}) => (
  <g>
    <defs><radialGradient id={`gl${id}`}><stop offset="0" stopColor={color} stopOpacity={0.6} /><stop offset="1" stopColor={color} stopOpacity={0} /></radialGradient></defs>
    <circle cx={x} cy={y} r={r * (0.95 + 0.05 * Math.sin(t * 0.6))} fill={`url(#gl${id})`} />
  </g>
);
export const Hut: React.FC<{t: number}> = ({t}) => (
  <g>
    <rect x={90} y={GROUND - 130} width={300} height={140} fill="#4d3622" />
    <polygon points={`60,${GROUND - 118} 240,${GROUND - 300} 420,${GROUND - 118}`} fill="#33251a" />
    {Array.from({length: 7}, (_, i) => <path key={i} d={`M${90 + i * 25} ${GROUND - 140 - i * 4} L${240} ${GROUND - 290}`} stroke="#241810" strokeWidth={3} />)}
    <rect x={200} y={GROUND - 110} width={80} height={110} fill="#ffb347" opacity={0.7 + 0.2 * Math.sin(t * 0.5)} />
  </g>
);
export const BurningTree: React.FC<{x: number; t: number}> = ({x, t}) => {
  const spots: [number, number, number][] = [[x, 330, 100], [x + 90, 300, 90], [x - 90, 360, 80], [x + 190, 430, 80], [x + 250, 440, 70], [x - 50, 260, 80], [x + 40, 230, 70], [x + 130, 360, 90]];
  return (
    <g>
      <path d={`M${x - 40} ${GROUND + 10} Q${x - 30} ${GROUND - 300} ${x - 18} 330 L${x + 18} 330 Q${x + 34} ${GROUND - 300} ${x + 44} ${GROUND + 10}Z`} fill="#1a110c" />
      <path d={`M${x} 450 L${x + 270} 420 L${x + 272} 436 L${x + 10} 480Z M${x - 5} 520 L${x - 160} 400 L${x - 148} 388 L${x + 5} 490Z M${x} 380 L${x - 70} 250 L${x - 56} 244 L${x + 14} 360Z M${x + 5} 360 L${x + 90} 240 L${x + 102} 248 L${x + 16} 390Z`} fill="#1a110c" />
      {spots.map(([sx, sy, ss], i) => <Flames key={i} x={sx} y={sy} size={ss} t={t} id={i} />)}
    </g>
  );
};
export const Weather: React.FC<{t: number; rain: number; flash?: boolean; vig?: number}> = ({t, rain, flash, vig = 0.6}) => {
  let light = 0, bx = 0;
  if (flash) FLASH.forEach((f) => { if (t >= f && t < f + 14) { const v = Math.exp(-(t - f) / 4) * ((t - f) % 5 === 2 ? 0.5 : 1); if (v > light) { light = v; bx = 400 + random('bolt' + f) * 1100; } } });
  return (
    <g>
      {Array.from({length: Math.floor(rain * 170)}, (_, i) => {
        const sp = 0.6 + random('rs' + i) * 0.6, x = random('rx' + i) * (W + 300);
        const y = (random('ry' + i) * H + t * 38 * sp) % H;
        return <line key={i} x1={x} y1={y} x2={x - 9} y2={y + 34} stroke="#b9d0f0" strokeWidth={1.4} opacity={0.3} />;
      })}
      {light > 0.3 && <path d={`M${bx} 0 L${bx - 30} 160 L${bx + 20} 230 L${bx - 40} 420 L${bx + 10} 470 L${bx - 60} 700`} stroke="#e6eeff" strokeWidth={7} fill="none" strokeLinejoin="round" />}
      <rect width={W} height={H} fill="#dfe8ff" opacity={light * 0.5} />
      <defs><radialGradient id="vig" cx="0.5" cy="0.5" r="0.75"><stop offset="0.5" stopColor="#000" stopOpacity={0} /><stop offset="1" stopColor="#000" stopOpacity={vig} /></radialGradient></defs>
      <rect width={W} height={H} fill="url(#vig)" />
    </g>
  );
};
export type Variant = 'hut' | 'forest' | 'grave' | 'tree';
export const Backdrop: React.FC<{variant: Variant; t: number; pan: number}> = ({variant, t, pan}) => (
  <g>
    <Sky warm={variant === 'tree'} /><Stars t={t} /><Moon /><Clouds t={t} dark={variant === 'forest' ? 0.85 : 0.6} />
    <Hills base={640} amp={90} seed={1} color="#0e1b33" f={0.12} pan={pan} />
    <Hills base={720} amp={70} seed={4} color="#0a1426" f={0.25} pan={pan} />
    {variant === 'hut' && <g><Trees n={16} base={800} size={0.8} color="#07111c" color2="#10223a" f={0.4} pan={pan} t={t} seed="hf" />
      <Hut t={t} /><Glow x={980} y={820} r={420} t={t} id="camp" /></g>}
    {variant === 'forest' && <g><River t={t} /><Trees n={18} base={780} size={0.9} color="#08131f" color2="#122641" f={0.5} pan={pan} t={t} seed="ff" /><Bats t={t} /></g>}
    {(variant === 'grave' || variant === 'tree') && <Trees n={14} base={790} size={0.9} color="#0b0f1a" color2="#162037" f={0.5} pan={pan} t={t} seed="gt" dead />}
    {variant === 'grave' && <g><Gravestones n={26} pan={pan} f={0.9} seed="gv" /><Ghosts t={t} pan={pan} />
      <Flames x={620 - pan * 0.9} y={GROUND + 10} size={70} t={t} id={20} /><Flames x={1600 - pan * 0.9} y={GROUND + 14} size={60} t={t} id={21} />
      <Glow x={620 - pan * 0.9} y={GROUND - 30} r={260} t={t} id="p1" /><Glow x={1600 - pan * 0.9} y={GROUND - 30} r={240} t={t} id="p2" /></g>}
    {variant === 'tree' && <g><Gravestones n={10} pan={0} f={0} seed="tg" /><Glow x={1380} y={560} r={900} t={t} id="tree" /><BurningTree x={1300} t={t} /></g>}
    <Ground pan={pan} />
    {variant === 'hut' && <Flames x={980} y={GROUND + 30} size={90} t={t} id={30} />}
  </g>
);
