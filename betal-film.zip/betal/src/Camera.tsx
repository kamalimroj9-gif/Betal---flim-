import React from 'react';
import {Easing, interpolate} from 'remotion';
export type Key = {f: number; x: number; y: number; z: number};
export const Camera: React.FC<{t: number; keys: Key[]; shake?: number; children: React.ReactNode}> = ({t, keys, shake = 0, children}) => {
  const fs = keys.map((k) => k.f);
  const ip = (p: 'x' | 'y' | 'z') => interpolate(t, fs, keys.map((k) => k[p]), {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.quad)});
  const sx = Math.sin(t * 1.7) * shake, sy = Math.cos(t * 2.3) * shake;
  return (
    <div style={{position: 'absolute', inset: 0, overflow: 'hidden'}}>
      <div style={{position: 'absolute', inset: 0, transformOrigin: '50% 50%', transform: `translate(${-ip('x') + sx}px, ${-ip('y') + sy}px) scale(${ip('z')})`}}>
        {children}
      </div>
    </div>
  );
};
