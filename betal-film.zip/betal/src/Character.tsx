import React from 'react';
import {Face, Mood} from './Face';
export type Pose = 'stand' | 'walk' | 'sit' | 'climb';
type Props = {
  x: number; y: number; s?: number; flip?: boolean; kind: 'king' | 'yogi'; pose: Pose; mood: Mood;
  frame: number; open?: number; climbY?: number; armFront?: number; elbowFront?: number;
};
const LOOK = {
  king: {skin: '#c98d5b', robe: '#8e1b2d', trim: '#e0b43a', pants: '#efe3c2'},
  yogi: {skin: '#b57a4c', robe: '#d9731a', trim: '#6e3410', pants: '#c9640f'},
};
const Limb: React.FC<{a: number; b: number; l1: number; l2: number; w: number; c: string; end?: React.ReactNode}> = ({a, b, l1, l2, w, c, end}) => (
  <g transform={`rotate(${a})`}>
    <rect x={-w / 2} y={-w / 2} width={w} height={l1 + w / 2} rx={w / 2} fill={c} />
    <g transform={`translate(0 ${l1}) rotate(${b})`}>
      <rect x={-w * 0.45} y={-w / 2} width={w * 0.9} height={l2 + w / 2} rx={w * 0.45} fill={c} />
      <g transform={`translate(0 ${l2})`}>{end}</g>
    </g>
  </g>
);
export const Character: React.FC<Props> = ({x, y, s = 1, flip, kind, pose, mood, frame, open = 0, climbY = 0, armFront, elbowFront}) => {
  const L = LOOK[kind];
  const ph = frame * 0.4, cp = frame * 0.3, br = Math.sin(frame / 12) * 2;
  let t1 = 0, k1 = 0, t2 = 0, k2 = 0, a1 = 5, e1 = -8, a2 = -5, e2 = -8, hip = -200 + br * 0.5;
  if (pose === 'walk') {
    t1 = -Math.sin(ph) * 30; k1 = Math.max(0, Math.cos(ph)) * 45;
    t2 = Math.sin(ph) * 30; k2 = Math.max(0, -Math.cos(ph)) * 45;
    a1 = Math.sin(ph) * 28; e1 = -18; a2 = -Math.sin(ph) * 28; e2 = -18;
    hip = -200 - Math.abs(Math.sin(ph)) * 8;
  } else if (pose === 'sit') {
    t1 = -90; k1 = 90; t2 = -82; k2 = 84; hip = -100 + br * 0.5;
    a1 = 14; e1 = -30; a2 = -38; e2 = -55;
  } else if (pose === 'climb') {
    t1 = -45 + Math.sin(cp) * 25; k1 = 50 - Math.sin(cp) * 25; t2 = -30 - Math.sin(cp) * 25; k2 = 40 + Math.sin(cp) * 25;
    a1 = -150 + Math.sin(cp) * 15; e1 = -10; a2 = -125 - Math.sin(cp) * 15; e2 = -15;
  }
  if (armFront !== undefined) { a2 = armFront; e2 = elbowFront ?? -10; }
  const tilt = Math.sin(frame / 20) * 1.5 + open * 2;
  const leg = (a: number, b: number) => (
    <Limb a={a} b={b} l1={100} l2={96} w={30} c={L.pants}
      end={<ellipse cx={10} cy={4} rx={26} ry={10} fill="#2a1a10" />} />
  );
  const hand = <circle r={11} fill={L.skin} />;
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
      <ellipse cx={20} cy={0} rx={120} ry={14} fill="#000" opacity={0.35} />
      <g transform={`translate(0 ${climbY})`}>
        <g transform={`translate(0 ${hip})`}>
          <g transform="translate(0 0)">{leg(t2, k2)}</g>
          <g transform="translate(0 -125)"><Limb a={a1} b={e1} l1={70} l2={64} w={22} c={L.robe} end={hand} /></g>
          <path d="M-36 -135 Q0 -152 36 -135 L32 0 L44 66 L-44 66 L-32 0 Z" fill={L.robe} />
          <path d="M-36 -135 Q0 -152 36 -135 L28 -110 Q0 -122 -28 -110Z" fill={L.trim} />
          <rect x={-33} y={-12} width={66} height={12} fill={L.trim} />
          <path d="M-44 66 L44 66" stroke={L.trim} strokeWidth={6} />
          {kind === 'yogi' && [0, 1, 2, 3, 4].map((i) => <circle key={i} cx={-12 + i * 6} cy={-118 + Math.sin(i / 4 * Math.PI) * 26} r={4} fill="#3a1f10" />)}
          <g transform="translate(0 0)">{leg(t1, k1)}</g>
          <g transform={`rotate(${tilt} 0 -140)`}>
            <g transform="translate(0 -185)">
              {kind === 'yogi' && <path d="M-30 14 Q-20 86 14 82 Q42 74 38 14 Q10 42 -30 14Z" fill="#d8d4c8" />}
              <Face mood={mood} open={open} frame={frame} skin={L.skin} />
              {kind === 'king' ? (
                <g>
                  <path d="M-42 -8 Q-46 -54 0 -54 Q44 -54 42 -10 Q20 -36 -42 -8Z" fill="#17100d" />
                  <polygon points="-32,-46 -36,-84 -17,-64 0,-94 17,-64 36,-84 32,-46" fill="#e0b43a" stroke="#a97c14" strokeWidth={2} />
                  <circle cx={0} cy={-62} r={5} fill="#b3122d" />
                  <path d="M10 14 Q22 10 32 14" stroke="#17100d" strokeWidth={4} fill="none" strokeLinecap="round" />
                </g>
              ) : (
                <g>
                  <path d="M-42 -6 Q-44 -52 0 -52 Q42 -52 40 -10 Q16 -30 -42 -6Z" fill="#cfcabc" />
                  <circle cx={-14} cy={-62} r={21} fill="#cfcabc" />
                  <path d="M6 -36 L24 -36" stroke="#b3202a" strokeWidth={4} strokeLinecap="round" />
                  <path d="M-2 -30 L28 -30" stroke="#f0ece0" strokeWidth={2} />
                  <path d="M4 15 Q16 9 32 15" stroke="#e6e2d6" strokeWidth={6} fill="none" strokeLinecap="round" />
                </g>
              )}
            </g>
          </g>
          <g transform="translate(0 -125)">
            <Limb a={a2} b={e2} l1={70} l2={64} w={22} c={L.robe}
              end={<g>{hand}{kind === 'king' && (
                <g transform="rotate(-80)"><rect x={-3} y={-8} width={6} height={22} fill="#5a3a12" />
                  <rect x={-14} y={12} width={28} height={6} fill="#e0b43a" />
                  <path d="M-6 18 L6 18 L3 150 L-3 150Z" fill="#dfe6ee" stroke="#8a97a8" strokeWidth={1.5} /></g>)}</g>} />
          </g>
        </g>
      </g>
    </g>
  );
};
// The corpse (Betal): origin at the feet, body extends upward (-y). Rotate 180 to hang by the feet.
export const Corpse: React.FC<{x: number; y: number; rot: number; frame: number; laugh?: boolean; s?: number}> = ({x, y, rot, frame, laugh, s = 0.9}) => {
  const j = laugh ? Math.sin(frame * 1.4) * 4 : 0;
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot + j}) scale(${s})`}>
      <path d="M-26 0 L-36 -190 Q0 -218 36 -190 L26 0 Z" fill="#d6cfbb" />
      <path d="M-18 -20 L-22 -180 M0 -10 L0 -200 M18 -20 L22 -180" stroke="#a79f8a" strokeWidth={3} />
      <path d="M-34 -180 Q-60 -130 -48 -70" stroke="#b9ad92" strokeWidth={14} fill="none" strokeLinecap="round" />
      <path d="M34 -180 Q58 -130 46 -70" stroke="#b9ad92" strokeWidth={14} fill="none" strokeLinecap="round" />
      <g transform="translate(0 -236)">
        <ellipse rx={36} ry={40} fill="#8c9a8a" />
        <path d="M-38 -10 Q-40 -50 0 -48 Q40 -50 38 -10 Q20 -34 -38 -10Z" fill="#14110f" />
        <ellipse cx={-13} cy={-4} rx={9} ry={11} fill="#101010" /><ellipse cx={13} cy={-4} rx={9} ry={11} fill="#101010" />
        <circle cx={-13} cy={-4} r={3} fill="#ff4b3a" /><circle cx={13} cy={-4} r={3} fill="#ff4b3a" />
        <path d="M-17 20 Q0 28 17 20" stroke="#2a0d0d" strokeWidth={4} fill="none" />
        {laugh && <ellipse cx={0} cy={24} rx={15} ry={10 + Math.abs(Math.sin(frame * 0.7)) * 8} fill="#2a0707" />}
      </g>
    </g>
  );
};
