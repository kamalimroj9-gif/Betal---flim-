import React from 'react';
export type Mood = 'calm' | 'brave' | 'shock' | 'happy';
export const Face: React.FC<{mood: Mood; open: number; frame: number; skin: string}> = ({mood, open, frame, skin}) => {
  const shock = mood === 'shock';
  const blink = frame % 110 < 4 ? 0.12 : 1;
  const ry = shock ? 9.5 : 6.5 * blink;
  const browY = shock ? -31 : mood === 'brave' ? -22 : -24;
  const tilt = mood === 'brave' ? 5 : shock ? -4 : 0;
  const brow = (cx: number, inner: number) => (
    <path d={`M${cx + inner * 10} ${browY + tilt} Q${cx} ${browY - 5 - (shock ? 3 : 0)} ${cx - inner * 10} ${browY - tilt * 0.4}`}
      stroke="#1b1109" strokeWidth={4} fill="none" strokeLinecap="round" />
  );
  const m = Math.max(open, shock ? 0.6 : 0);
  return (
    <g>
      <ellipse cx={-36} cy={4} rx={7} ry={11} fill={skin} />
      <ellipse cx={0} cy={0} rx={40} ry={44} fill={skin} />
      <ellipse cx={-14} cy={10} rx={22} ry={30} fill="#000" opacity={0.08} />
      {[-8, 22].map((cx, i) => (
        <g key={i}>
          <ellipse cx={cx} cy={-4} rx={9} ry={ry} fill="#f6f1e6" />
          <circle cx={cx + 3} cy={-4} r={shock ? 2.6 : 3.8} fill="#1b1109" />
          <path d={`M${cx - 9} ${-4 - ry} Q${cx} ${-4 - ry - 4} ${cx + 9} ${-4 - ry}`} stroke="#1b1109" strokeWidth={2.2} fill="none" />
        </g>
      ))}
      {brow(-8, 1)}{brow(22, -1)}
      <path d="M32 -2 Q41 11 31 15" stroke="#00000055" strokeWidth={3} fill="none" strokeLinecap="round" />
      {m > 0.08 ? (
        <g>
          <ellipse cx={13} cy={27} rx={8 + m * 3} ry={2 + m * 13} fill="#3a0c0c" />
          <ellipse cx={13} cy={27 + m * 7} rx={5} ry={Math.max(1, m * 4)} fill="#c0504f" />
        </g>
      ) : mood === 'happy' ? (
        <path d="M2 24 Q13 36 25 24" stroke="#3a0c0c" strokeWidth={3.5} fill="none" strokeLinecap="round" />
      ) : (
        <path d={mood === 'brave' ? 'M3 28 L24 27' : 'M3 27 Q13 30 24 27'} stroke="#3a0c0c" strokeWidth={3.5} fill="none" strokeLinecap="round" />
      )}
    </g>
  );
};
