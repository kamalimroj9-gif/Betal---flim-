export const FPS = 24, W = 1920, H = 1080, GROUND = 880, FOOT = 905, TOTAL = 1260;
// scene boundaries (global frames): hut | night walk | graveyard | burning tree
export const B = [0, 420, 660, 900, 1260];
export type Who = 'yogi' | 'king' | 'narr' | 'corpse';
export type Sub = {from: number; to: number; who: Who; text: string};
// Text: Vidyasagar, Betal Panchabinshati (1847, public domain)
export const SUBS: Sub[] = [
  {from: 50, to: 100, who: 'yogi', text: 'এই আসনে উপবেশ কর।'},
  {from: 110, to: 165, who: 'king', text: 'মহাশয়! ভৃত্যের প্রতি কি আজ্ঞা হয়।'},
  {from: 175, to: 250, who: 'yogi', text: 'মহারাজ! তোমার বাক্যনিষ্ঠায় নিরতিশয় সন্তুষ্ট হইয়াছি।'},
  {from: 260, to: 330, who: 'yogi', text: 'দুই ক্রোশ দক্ষিণে এক শ্মশান আছে; তথায় এক শিরীষবৃক্ষে শব ঝুলিতেছে;'},
  {from: 335, to: 385, who: 'yogi', text: 'ঐ শব আমার নিকটে লইয়া আইস।'},
  {from: 390, to: 418, who: 'king', text: 'যে আজ্ঞা।'},
  {from: 435, to: 520, who: 'narr', text: 'একে কৃষ্ণচতুর্দ্দশীর রাত্রি সহজেই ঘোরতর অন্ধকারে আবৃতা;'},
  {from: 525, to: 608, who: 'narr', text: 'মুষলধারায় বৃষ্টি হইতেছিল; ভূতপ্রেতগণ চতুর্দ্দিকে ভয়ানক কোলাহল করিতেছিল।'},
  {from: 612, to: 656, who: 'narr', text: 'কিন্তু রাজার তাহাতে ভয় বা ব্যাকুলতার লেশ মাত্র উপস্থিত হইল না।'},
  {from: 670, to: 730, who: 'narr', text: 'রাজা নির্দ্দিষ্ট প্রেতভূমিতে উপনীত হইলেন;'},
  {from: 735, to: 830, who: 'narr', text: 'দেখিলেন, কোনও স্থলে অতি বিকট-মূর্ত্তি ভূতপ্রেতগণ, জীবিত মনুষ্য ধরিয়া,'},
  {from: 835, to: 895, who: 'narr', text: 'রাজা, ইতস্ততঃ অনেক অন্বেষণ করিয়া,'},
  {from: 908, to: 990, who: 'narr', text: 'উহার মূল অবধি অগ্রভাগ পর্য্যন্ত, প্রত্যেক বিটপ ও পল্লব ধক্ ধক্ করিয়া জ্বলিতেছে;'},
  {from: 995, to: 1040, who: 'narr', text: 'এই সমস্ত দেখিয়া শুনিয়াও, রাজা ভয় পাইলেন না;'},
  {from: 1045, to: 1100, who: 'narr', text: 'নির্ভয়ে বৃক্ষে আরোহণ পূর্ব্বক, খড়্গাঘাত দ্বারা, শবের বন্ধনরজ্জু ছিন্ন করিলেন।'},
  {from: 1105, to: 1150, who: 'narr', text: 'শব, ভূতলে পতিত হইবা মাত্র, উচ্চৈঃস্বরে রোদন করিতে লাগিল।'},
  {from: 1155, to: 1200, who: 'king', text: 'তুমি কে, কি নিমিত্তে তোমার এরূপ দুরবস্থা ঘটিয়াছে, বল।'},
  {from: 1205, to: 1250, who: 'narr', text: 'শব খিল্ খিল্ করিয়া হাসিয়া উঠিল।'},
];
export const FLASH = [470, 565, 700, 845, 950];
export const WALK_RANGES: [number, number][] = [[10, 70], [425, 985]];
export const activeSub = (t: number) => SUBS.find((s) => t >= s.from && t <= s.to);
// Text-driven lip sync: the vowel sign under the playhead picks the mouth shape.
export const lipOpen = (t: number, who: Who) => {
  const s = activeSub(t);
  if (!s || s.who !== who) return 0;
  const p = (t - s.from) / (s.to - s.from);
  const c = s.text[Math.min(s.text.length - 1, Math.floor(p * s.text.length))];
  const v = 0.8 + 0.2 * Math.sin(t * 2.1);
  if ('াোআঅৌ'.includes(c)) return 1 * v;
  if ('েিীএইঐ'.includes(c)) return 0.55 * v;
  if ('ুূউও'.includes(c)) return 0.35 * v;
  if (c === ' ' || c === '।' || c === ';' || c === ',') return 0;
  return 0.18 * v;
};
