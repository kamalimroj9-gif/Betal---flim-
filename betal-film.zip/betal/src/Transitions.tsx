import React from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
// Cross-fade: the incoming scene sits on top of the outgoing one and fades in.
export const Fade: React.FC<{f: number; frames: number; children: React.ReactNode}> = ({f, frames, children}) => (
  <AbsoluteFill style={{opacity: frames ? interpolate(f, [0, frames], [0, 1], {extrapolateRight: 'clamp'}) : 1}}>{children}</AbsoluteFill>
);
export const FadeBlack: React.FC<{t: number; total: number}> = ({t, total}) => (
  <AbsoluteFill style={{background: '#000', opacity: Math.max(interpolate(t, [0, 24], [1, 0], {extrapolateRight: 'clamp'}), interpolate(t, [total - 30, total], [0, 1], {extrapolateLeft: 'clamp'})), pointerEvents: 'none'}} />
);
