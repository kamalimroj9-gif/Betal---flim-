import React from 'react';
import {AbsoluteFill, Sequence, interpolate, Easing, useCurrentFrame} from 'remotion';
import {loadFont} from '@remotion/google-fonts/NotoSansBengali';
import {B, W, H, TOTAL, FOOT, GROUND, SUBS, activeSub, lipOpen} from './constants';
import {Character, Corpse} from './Character';
import {Backdrop, Weather, Variant} from './Backgrounds';
import {Camera, Key} from './Camera';
import {Fade, FadeBlack} from './Transitions';
import {MusicTrack, SoundEffects} from './Sound';
const {fontFamily} = loadFont();
const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const lerp = (t: number, a: number[], b: number[], easing?: (n: number) => number) => interpolate(t, a, b, {...cl, easing});

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', inset: 0}}>{children}</svg>
);
const Scene: React.FC<{start: number; end: number; fade: boolean; children: (t: number) => React.ReactNode}> = ({start, end, fade, children}) => (
  <Sequence from={start} durationInFrames={end - start}><SceneInner start={start} fade={fade}>{children}</SceneInner></Sequence>
);
const SceneInner: React.FC<{start: number; fade: boolean; children: (t: number) => React.ReactNode}> = ({start, fade, children}) => {
  const f = useCurrentFrame();
  return <Fade f={f} frames={fade ? 12 : 0}>{children(f + start)}</Fade>;
};

// Scene 1: the yogi's clearing. The king arrives, sits, receives the task.
const SceneHut = ({t}: {t: number}) => {
  const walking = t < 70, sitting = t >= 70 && t < 400;
  const kx = lerp(t, [0, 70], [2150, 1330]);
  const gest = lipOpen(t, 'yogi') > 0 ? -80 + Math.sin(t / 5) * 12 : undefined;
  return (
    <Camera t={t} keys={[{f: 0, x: 0, y: 0, z: 1}, {f: 420, x: 70, y: -25, z: 1.2}]}>
      <Stage>
        <Backdrop variant="hut" t={t} pan={0} />
        <ellipse cx={1350} cy={FOOT} rx={190} ry={18} fill="#5a2a1c" opacity={0.8} />
        <ellipse cx={640} cy={FOOT} rx={190} ry={18} fill="#6a4a20" opacity={0.8} />
        <Character kind="yogi" x={600} y={FOOT} s={1.25} pose="sit" mood="calm" frame={t} open={lipOpen(t, 'yogi')} armFront={gest} elbowFront={-35} />
        <Character kind="king" x={kx} y={FOOT} s={1.25} flip pose={walking ? 'walk' : sitting ? 'sit' : 'stand'} mood="calm" frame={t} open={lipOpen(t, 'king')} />
        <Weather t={t} rain={0} vig={0.55} />
      </Stage>
    </Camera>
  );
};
// Scene 2: walking through the stormy night; the world scrolls by in parallax.
const SceneWalk = ({t}: {t: number}) => (
  <Camera t={t} shake={1.2} keys={[{f: 408, x: 0, y: 0, z: 1.05}, {f: 660, x: -80, y: -20, z: 1.2}]}>
    <Stage>
      <Backdrop variant="forest" t={t} pan={(t - 408) * 5} />
      <Character kind="king" x={780} y={FOOT} s={1.3} pose="walk" mood={t > 600 ? 'brave' : 'calm'} frame={t} open={0} />
      <Weather t={t} rain={1} flash vig={0.7} />
    </Stage>
  </Camera>
);
// Scene 3: the graveyard with spirits drifting overhead.
const SceneGrave = ({t}: {t: number}) => {
  const x = lerp(t, [648, 880], [250, 1200]);
  return (
    <Camera t={t} shake={2} keys={[{f: 648, x: 0, y: 0, z: 1}, {f: 900, x: 60, y: -30, z: 1.15}]}>
      <Stage>
        <Backdrop variant="grave" t={t} pan={(t - 648) * 1.5} />
        <Character kind="king" x={x} y={FOOT} s={1.3} pose={t < 885 ? 'walk' : 'stand'} mood="brave" frame={t} />
        <Weather t={t} rain={0.8} flash vig={0.7} />
      </Stage>
    </Camera>
  );
};
// Scene 4: the burning tree, the climb, the cut rope, the laughing corpse.
const SceneTree = ({t}: {t: number}) => {
  const kx = t < 990 ? lerp(t, [888, 990], [220, 930]) : lerp(t, [1030, 1050], [930, 1262]);
  const climbing = (t >= 1045 && t < 1140);
  const climbY = t < 1090 ? lerp(t, [1048, 1088], [0, -240]) : lerp(t, [1108, 1140], [-240, 0]);
  const slash = t >= 1080 && t < 1105 ? lerp(t, [1080, 1090, 1104], [-165, -55, -170]) : undefined;
  const pose = t < 990 ? 'walk' : t >= 1030 && t < 1050 ? 'walk' : climbing ? 'climb' : 'stand';
  const mood = t < 1105 ? 'brave' : 'shock';
  const hang = t < 1092;
  const fall = Easing.in(Easing.quad)(lerp(t, [1092, 1108], [0, 1]));
  const rise = Easing.out(Easing.quad)(lerp(t, [1200, 1216], [0, 1]));
  const rot = hang ? 180 + Math.sin(t / 12) * 3 : 180 - fall * 90 - rise * 70;
  const cy = hang ? 520 : 520 + fall * (FOOT - 520);
  const cx = 1480 + (hang ? 0 : fall * 25);
  return (
    <Camera t={t} shake={t > 1090 ? 2 : 0.8} keys={[{f: 888, x: 0, y: 0, z: 1}, {f: 1040, x: 120, y: 0, z: 1.1}, {f: 1100, x: 250, y: -40, z: 1.15}, {f: 1170, x: 560, y: 120, z: 1.45}, {f: 1260, x: 600, y: 150, z: 1.55}]}>
      <Stage>
        <Backdrop variant="tree" t={t} pan={0} />
        {hang ? <path d={`M1480 428 L${cx} 520`} stroke="#8a6a3a" strokeWidth={5} />
          : <path d={`M1480 428 Q${1476 + Math.sin(t / 5) * 8} 470 1482 490`} stroke="#8a6a3a" strokeWidth={5} fill="none" />}
        <Corpse x={cx} y={cy} rot={rot} frame={t} laugh={t >= 1205} />
        <Character kind="king" x={kx} y={FOOT} s={1.3} pose={pose as any} mood={mood as any} frame={t} climbY={climbY} armFront={slash} elbowFront={-5} open={lipOpen(t, 'king')} />
        <Weather t={t} rain={0.3} flash vig={0.75} />
        <rect width={W} height={H} fill="#ff7a1a" opacity={0.06 + 0.03 * Math.sin(t * 0.6)} style={{mixBlendMode: 'screen'}} />
      </Stage>
    </Camera>
  );
};
const Subtitles: React.FC<{t: number}> = ({t}) => {
  const s = activeSub(t);
  if (!s) return null;
  const op = lerp(t, [s.from, s.from + 4, s.to - 3, s.to], [0, 1, 1, 0]);
  const label = s.who === 'yogi' ? 'যোগী' : s.who === 'king' ? 'রাজা' : '';
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 56, display: 'flex', justifyContent: 'center', opacity: op, fontFamily}}>
      <div style={{background: 'rgba(5,8,16,0.72)', padding: '16px 34px', borderRadius: 10, maxWidth: 1500, textAlign: 'center', color: '#f6f0dc', fontSize: 44, lineHeight: 1.5, borderBottom: '3px solid #e0b43a'}}>
        {label && <span style={{color: '#e0b43a', marginRight: 16, fontWeight: 700}}>{label}:</span>}{s.text}
      </div>
    </div>
  );
};
export const Film: React.FC = () => {
  const frame = useCurrentFrame();
  const sc = [SceneHut, SceneWalk, SceneGrave, SceneTree];
  return (
    <AbsoluteFill style={{background: '#000'}}>
      {sc.map((S, i) => (
        <Scene key={i} start={B[i] - (i ? 12 : 0)} end={B[i + 1]} fade={i > 0}>{(t) => <S t={t} />}</Scene>
      ))}
      <Subtitles t={frame} />
      <FadeBlack t={frame} total={TOTAL} />
      <MusicTrack />
      <SoundEffects />
    </AbsoluteFill>
  );
};
